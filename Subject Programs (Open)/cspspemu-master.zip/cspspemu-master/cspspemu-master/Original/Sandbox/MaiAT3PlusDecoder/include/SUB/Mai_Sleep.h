#ifndef Mai_Sleep_h
#define Mai_Sleep_h

#include "SUB/Mai_All.h"

Mai_Status Mai_Sleep(Mai_U32 millisec);

#endif
