namespace cscodec.h264.decoder
{
	public class RL_VLC_ELEM
	{
		public short level; //int16_t level;
		public int len; //int8_t len;
		public int run; //uint8_t run;
	}
}