namespace cscodec.h264.decoder
{
	public struct VLCcode
	{
		public byte bits;
		public ushort symbol;
		public uint code;
	}
}
