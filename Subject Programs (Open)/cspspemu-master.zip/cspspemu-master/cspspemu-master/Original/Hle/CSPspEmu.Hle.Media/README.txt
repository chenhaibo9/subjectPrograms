﻿Port of h264j:
A pure JAVA H264 Decoder ported from FFmpeg (libavcodec) library.
http://code.google.com/p/h264j/