﻿namespace CSPspEmu.Core
{
	public delegate void WakeUpCallbackDelegate();
}
