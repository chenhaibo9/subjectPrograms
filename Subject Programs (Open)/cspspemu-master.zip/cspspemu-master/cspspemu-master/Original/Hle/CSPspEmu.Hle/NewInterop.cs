﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSPspEmu.Core.Components
{
	public class NewInterop
	{
		public void ExecuteFunctionLater(uint Function, Action<uint> ExecutedCallback, params object[] Arguments)
		{
			//throw
			Console.WriteLine("Not implemented NewInterop.ExecuteFunctionLater");
		}
	}
}
