﻿using System;

namespace CSPspEmu.Hle
{
	public sealed class HleEmulatorFinalizeCallbackException : Exception
	{
	}
}
