﻿namespace CSPspEmu.Hle.Threading.Semaphores
{
	public enum SemaphoreId : int { }
}
