﻿namespace CSPspEmu.Hle.Threading.Semaphores
{
	public struct SceKernelSemaOptParam
	{
		/// <summary>
		/// Size of the ::SceKernelSemaOptParam structure.
		/// </summary>
		public uint Size;
	}
}
