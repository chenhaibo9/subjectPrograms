﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSPspEmu.Hle.Loader
{
	public class ElfConfig
	{
		/// <summary>
		/// 
		/// </summary>
		public bool InfoExeHasRelocation;

		/// <summary>
		/// 
		/// </summary>
		public uint RelocatedBaseAddress;

		/// <summary>
		/// 
		/// </summary>
		public string GameTitle;
	}
}
