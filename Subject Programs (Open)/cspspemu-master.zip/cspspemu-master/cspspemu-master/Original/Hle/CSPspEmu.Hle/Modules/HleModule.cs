﻿using System;
using CSPspEmu.Core;

namespace CSPspEmu.Hle
{
	public class HleModule : IDisposable
	{
		public virtual void Dispose()
		{
		}
	}
}
