﻿namespace CSPspEmu.Hle.Vfs
{
	public enum SeekAnchor : int
	{
		Set = 0,
		Cursor = 1,
		End = 2,
	}
}
