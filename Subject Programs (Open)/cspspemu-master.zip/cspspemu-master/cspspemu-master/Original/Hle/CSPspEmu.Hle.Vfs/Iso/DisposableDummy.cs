﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSPspEmu.Hle.Vfs.Iso
{
	/*
	public class DisposableDummy<TType> : IDisposable
	{
		protected TType Object;

		public DisposableDummy(TType Object)
		{
			this.Object = Object;
		}

		public static implicit operator DisposableDummy<TType>(TType Object)
		{
			return new DisposableDummy<TType>(Object);
		}

		public static implicit operator TType(DisposableDummy<TType> Object)
		{
			return Object.Object;
		}

		public void Dispose()
		{
		}
	}
	*/
}
