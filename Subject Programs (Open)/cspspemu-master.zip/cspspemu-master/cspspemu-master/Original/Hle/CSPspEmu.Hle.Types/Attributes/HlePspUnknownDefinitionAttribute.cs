﻿using System;

namespace CSPspEmu.Hle
{
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	public sealed class HlePspUnknownDefinitionAttribute : Attribute
	{
	}
}
