﻿using System;

namespace CSPspEmu.Hle
{
	public sealed class SceKernelSelfStopUnloadModuleException : Exception
	{
	}
}
