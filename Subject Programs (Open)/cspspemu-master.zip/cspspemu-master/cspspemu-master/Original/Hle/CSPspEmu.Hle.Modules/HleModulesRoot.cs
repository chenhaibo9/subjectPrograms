﻿namespace CSPspEmu.Hle.Modules
{
	public class HleModulesRoot
	{
	}
}
