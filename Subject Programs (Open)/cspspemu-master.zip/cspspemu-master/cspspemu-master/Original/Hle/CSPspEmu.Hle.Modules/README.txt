﻿Here should go all the hle kernel modules.
This package should be just an interface with no code or states when possible
that interface classes on the CSPspEmu.Hle.