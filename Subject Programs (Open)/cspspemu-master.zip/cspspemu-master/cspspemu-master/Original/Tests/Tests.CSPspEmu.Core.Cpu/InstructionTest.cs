﻿using CSPspEmu.Core.Cpu.Table;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace CSPspEmu.Core.Tests
{
	[TestClass]
	public class InstructionTest
	{
		[TestMethod]
		public void InstructionConstructorTest()
		{
		}
	}
}
