﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Animal
    {
        protected int age;
        protected bool alive;
        protected Location location;

        protected int breedingAge;
        protected double breedingProbability;
        protected int maxAge;
        protected int maxLitterSize;
        //protected Random rand = new Random();
        public bool done;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="age"></param>
        /// <param name="alive"></param>
        /// <param name="breedingAge"></param>
        /// <param name="breedingProbability"></param>
        /// <param name="maxAge"></param>
        /// <param name="maxLitterSize"></param>
        /// <param name="done"></param>
        /// <param name="location"></param>
        public void AnimalInitialize(int age, bool alive, int breedingAge, double breedingProbability, int maxAge, int maxLitterSize, bool done, Location location)
        {
            this.age = age;
            this.alive = alive;
            this.breedingAge = breedingAge;
            this.breedingProbability = breedingProbability;
            this.maxAge = maxAge;
            this.maxLitterSize = maxLitterSize;
            this.done = done;
            this.location = location;
        }
       /// <summary>
       /// 
       /// </summary>
        public Animal()
        {
            age = 0;
            alive = true;
            done = false;
        }
    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool isAlive()
        {
            return alive;
        }


        /// <summary>
        /// 
        /// </summary>
        public void die()
        {
            alive = false;
        }
    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int getAge()
        {
            return age;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="age"></param>
        public void setAge(int age)
        {
            this.age = age;
        }

        
        /// <summary>
        /// 返回位置的值
        /// </summary>
        /// <returns></returns>
        public int getLocation()
        {
            int index = location.getIndex();
            return index;
        }

      
        /// <summary>
        /// 设置位置的值
        /// </summary>
        /// <param name="location"></param>
        public void setLocation(Location location)
        {
            this.location = location;

        } 

      
        /// <summary>
        /// 设置位置的值
        /// </summary>
        /// <param name="index"></param>
        public void setLocation(int index)
        {
            this.location = new Location(index);
        }

        //public abstract void act(Field field, Random rand1, List<Animal> animals, List<Animal> newAnimals);


        /// <summary>
        /// 年龄加1，并判断生死
        /// </summary>
        public void incrementAge() 
        {
	        age += 1;

            if (age > maxAge)
            {
                alive = false;
            }

        }


        /// <summary>
        /// 是否到生育年龄
        /// </summary>
        /// <returns></returns>
        public bool ofBreedingAge()
        {
            if (age >= breedingAge)
            {
                return true;
            }

            else
            {
                return false;
            }

        }


        /// <summary>
        /// 生育数量
        /// </summary>
        /// <returns></returns>
        public int numberOffspring()
        {
            Random ran = new Random();
            if (!ofBreedingAge())
            {
                return 0;
            }

            else
            {
                if (ran.NextDouble() < breedingProbability)
                {
                    int num = 1 + (int)(ran.NextDouble() * maxLitterSize);
                    return num;
                }
                else
                {
                    return 0;
                }
            }

        }
  
    }
}
