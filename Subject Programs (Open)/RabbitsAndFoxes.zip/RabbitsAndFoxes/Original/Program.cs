﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int DEFAULT_WIDTH = 4000;
            int DEFAULT_HEIGHT = 1;
            double FOX_CREATION_PROBABILITY = 0.02;
            double RABBIT_CREATION_PROBABILITY = 0.06;    

            
            Field field=new Field(DEFAULT_HEIGHT, DEFAULT_WIDTH);

            List<Animal> animals = new List<Animal>();
	        int height = field.getHeight();
	        int width = field.getWidth();
            Random rand1 = new Random();

            for (int row = 0; row < height; row++ ) //初始状态，产生动物
            {
	            for (int col = 0; col < width; col++ ) 
                {
		            if (rand1.NextDouble() < FOX_CREATION_PROBABILITY) 
                    {
		                Fox fox = new Fox();
		                fox.setLocation( new Location(col));
		                field.placeInField(fox);
		                animals.Add(fox);
		            }
		            else 
                    {

		                if (rand1.NextDouble() < RABBIT_CREATION_PROBABILITY) 
                        {
			                Rabbit rabbit = new Rabbit();
			                rabbit.setLocation(new Location(col));
			                field.placeInField(rabbit);
			                animals.Add(rabbit);
		                }
		            }
	            }
	        }
            //初始状态统计
            int count1 = 0;
            int count2 = 0;
            for (int i= 0; i < animals.Count; i++)
            {
                if(animals[i] is Rabbit)
                {
                    count1++;
                }
                else if (animals[i] is Fox)
                {
                    count2++;
                }
            }
             
            Console.WriteLine("兔子数量:" + count1 + "  狐狸数量:" + count2);


            for (int step = 1; step <= 100; step++)
            {
                List<Animal> newAnimals = new List<Animal>();
                //for (int t = 0; t < animals.Count; t++)
                //{
                //    animals[t].act(field, rand1, animals, newAnimals);
                //}
                List<Animal> dead = new List<Animal>();
                for (int m = 0; m < animals.Count; m++)
                {
                    if (animals[m].isAlive() == false)
                    {
                        dead.Add(animals[m]);
                    }

                }
                foreach (Animal n in dead)
                {
                    animals.Remove(n);
                }
                foreach (Animal every in newAnimals)
                {
                    animals.Add(every);
                }
                int count3 = 0;
                int count4 = 0;
                for (int j = 0; j < animals.Count; j++)
                {
                    if (animals[j] is Rabbit)
                    {
                        count3++;
                    }
                    else if (animals[j] is Fox)
                    {
                        count4++;
                    }
                }
                Console.WriteLine("兔子数量:" + count3 + "  狐狸数量:" + count4);

            }
            Console.Read();
		
        }        
    }
}
