﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Field
    {
        private int height;
        private int width;
        private int[] field=new int[100];

        private Random rand = new Random();


        /// <summary>
        /// 
        /// </summary>
        /// <param name="h"></param>
        /// <param name="w"></param>
        public Field(int h,int w)
        {
            height = h;
            width = w;
            //field = new int[w];
        }

        /// <summary>
        /// 
        /// </summary>
        public Field()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="height"></param>
        /// <param name="width"></param>
        /// <param name="field"></param>
        public void FieldInitialize(int height,int width,int[] field)
        {
            this.height=height;
            this.width=width;
            this.field=field;
        }

        /// <summary>
        /// 将动物放置在field中
        /// </summary>
        /// <param name="a"></param>
        public void placeInField(Animal a)
        {
            int index = a.getLocation();

            //int col = loc.getCol();
            if (a is Rabbit)
            {
                field[index] = 1;
            }
            else if (a is Fox)
            {
                field[index] = 2;
            }
        }


        /// <summary>
        /// 将动物从field中移除
        /// </summary>
        /// <param name="a"></param>
        public void removeFromField(Animal a)
        {
            int index = a.getLocation();
            //int row = loc.getRow();
            //int col = loc.getCol();
            field[index] = -1;
        }

       
        /// <summary>
        /// Return the animal at the given location, if any.
       /// </summary>
       /// <param name="location"></param>
       /// <returns></returns>
        public int getObjectAt(Location location)
        {
            return getObjectAt(location.getIndex());
        }

       
        /// <summary>
        /// Return the animal at the given location, if any.
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public int getObjectAt(int row)
        {
            return field[row];
        }

      
        /// <summary>
        /// 随机获取相邻的位置，可能与原位置一样
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public int randomAdjacentLocation(Location location)
        {
            int index = location.getIndex();
            int row = index / 10;
            int col = index % 10;
            // Generate an offset of -1, 0, or +1 for both the current row and col.

            int randomindex;
            int nextRow = (row + 10 + rand.Next(3) - 1) % 10;
            int nextCol = (col + 10 + rand.Next(3) - 1) % 10;
            randomindex = nextRow * 10 + nextCol;
            return randomindex;
        }

        
        /// <summary>
        /// 从相邻的位置中找到空位，没有的话，尝试原先位置
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public int findFreeAdjacentLocation(Location location)
        {

            //相邻的位置，并打乱顺序（不包括本身）
            int index = location.getIndex();
            int row = index / 10;
            int col = index % 10;
            List<Location> locations = new List<Location>();

            for (int roffset = -1; roffset <= 1; roffset++)
            {
                int nextRow = (row + roffset + 10) % 10;
                for (int coffset = -1; coffset <= 1; coffset++)
                {
                    int nextCol = (col + coffset + 10) % 10;
                    int nextindex = nextRow * 10 + nextCol;
                    // Exclude the original location.
                    if (roffset != 0 || coffset != 0)
                    {
                        locations.Add(new Location(nextindex));
                    }
                }
            }

            Random rand3 = new Random();
            List<Location> newlocations = new List<Location>();
            for (int i = 8; i > 0; i--)
            {
                int j = rand3.Next(0, i);
                newlocations.Add(locations[j]);
                locations.Remove(locations[j]);
            }

            //从相邻的位置中找到空位，没有的话，尝试原先位置
            foreach (Location i in newlocations)
            {
                Location next = (Location)i;
                int value = field[next.getIndex()];
                if (value == -1)
                {
                    int index1 = next.getIndex();
                    return index1;
                }
                //else if (!animal.isAlive())
                //    return next;
            }

            // if all adjacent locations are full, try the current location
            if (field[location.getIndex()] == -1)
            {
                int index2 = location.getIndex();
                return index2;
            }
            else
            {
                return -1;
            }
        }

       ///// <summary>
       // /// 相邻的位置，并打乱顺序（不包括本身）
       ///// </summary>
       ///// <param name="location"></param>
       ///// <returns></returns>
       // public List<Location> adjacentLocations(Location location)
       // {
       //     int row = location.getRow();
       //     int col = location.getCol();
       //     List<Location> locations = new List<Location>();
       //     for (int roffset = -1; roffset <= 1; roffset++)
       //     {
       //         int nextRow = (row + roffset + height) % height;
       //         for (int coffset = -1; coffset <= 1; coffset++)
       //         {
       //             int nextCol = (col + coffset + width) % width;
       //             // Exclude the original location.
       //             if (roffset != 0 || coffset != 0)
       //             {
       //                 locations.Add(new Location(nextRow, nextCol));
       //             }
       //         }
       //     }
       //     Random rand3 = new Random();
       //     List<Location> newlocations = new List<Location>();
       //     for (int i = 8; i > 0; i--)
       //     {
       //         int j = rand3.Next(0, i);
       //         newlocations.Add(locations[j]);
       //         locations.Remove(locations[j]);
       //     }
       //     return newlocations;

       // }

       
        /// <summary>
        /// return The height of the field.
        /// </summary>
        /// <returns></returns>
        public int getHeight()
        {
            return height;
        }

       
        /// <summary>
        /// return The width of the field.
        /// </summary>
        /// <returns></returns>
        public int getWidth()
        {
            return width;
        }

    }
}
