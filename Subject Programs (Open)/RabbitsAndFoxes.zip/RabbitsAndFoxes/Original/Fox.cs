﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Fox:Animal
    {
        private  int BREEDING_AGE = 10;
        public  int MAX_AGE = 20;
        private  double BREEDING_PROBABILITY = 0.15;
        private  int MAX_LITTER_SIZE = 3;
        private  int RABBIT_FOOD_VALUE = 4 ;
    
        private int foodLevel;
        private Random rand = new Random();

        
        /// <summary>
        /// Constructor to create a newborn fox (age = 0)
        /// </summary>
        public Fox():this(0)
        {
            foodLevel = RABBIT_FOOD_VALUE;
        }
        public void FoxInitialize(int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int RABBIT_FOOD_VALUE, int foodLevel, int age, bool alive, int breedingAge, double breedingProbability, int maxAge, int maxLitterSize, bool done, Location location)
        {
            this.BREEDING_AGE=BREEDING_AGE;
            this.MAX_AGE=MAX_AGE;
            this.BREEDING_PROBABILITY=BREEDING_PROBABILITY;
            this.MAX_LITTER_SIZE=MAX_LITTER_SIZE;
            this.RABBIT_FOOD_VALUE=RABBIT_FOOD_VALUE;
            this.foodLevel=foodLevel;
            this.age = age;
            this.alive = alive;
            this.breedingAge = breedingAge;
            this.breedingProbability = breedingProbability;
            this.maxAge = maxAge;
            this.maxLitterSize = maxLitterSize;
            this.done = done;
            this.location = location;
        }
        
        /// <summary>
        /// Constructor to create a fox of the given age
        /// </summary>
        /// <param name="age"></param>
        public Fox(int age): base()
        {
            breedingAge = BREEDING_AGE;
            maxAge = MAX_AGE;
            breedingProbability = BREEDING_PROBABILITY;
            maxLitterSize = MAX_LITTER_SIZE;

            setAge(age);

            foodLevel = rand.Next(RABBIT_FOOD_VALUE);
        } 


        /// <summary>
        /// 饥饿值-1，判断生死
        /// </summary>
        public void incrementHunger() 
        {
	        foodLevel -= 1;
	        if (foodLevel == 0)
	            alive = false;
        }


        /// <summary>
        /// 吃兔子，饥饿值+4，兔子死
        /// </summary>
        /// <param name="food"></param>
        public void eat(Rabbit food) 
        {
	        foodLevel += RABBIT_FOOD_VALUE;
	        food.die();
        }


        /// <summary>
        /// 找到食物的位置
        /// </summary>
        /// <param name="field"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        public int findFood(Field field, Location location) 
        {
            int index = location.getIndex();
            int row = index / 10;
            int col = index % 10;
            List<Location> locations = new List<Location>();

            for (int roffset = -1; roffset <= 1; roffset++)
            {
                int nextRow = (row + roffset + 10) % 10;
                for (int coffset = -1; coffset <= 1; coffset++)
                {
                    int nextCol = (col + coffset + 10) % 10;
                    int nextindex = nextRow * 10 + nextCol;
                    // Exclude the original location.
                    if (roffset != 0 || coffset != 0)
                    {
                        locations.Add(new Location(nextindex));
                    }
                }
            }

            Random rand4 = new Random();
            List<Location> newlocations = new List<Location>();

            for (int i = 8; i > 0; i--)
            {
                int j = rand4.Next(0, i);
                newlocations.Add(locations[j]);
                locations.Remove(locations[j]);
            }
	        
	        foreach(Location i in newlocations) 
            {
	            Location loc = (Location) i;
                int newindex = loc.getIndex();
	            int an = field.getObjectAt(newindex);
	            if (an != -1) 
                {
		            if (an == 1) 
                    {
		                return newindex;
		            }  
	            }
	        } 
  
	        return -1;
        }

    }
}
