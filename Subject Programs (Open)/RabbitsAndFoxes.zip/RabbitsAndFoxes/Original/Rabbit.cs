﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Rabbit:Animal
    {
        private  int BREEDING_AGE = 5;
        public  int MAX_AGE = 10;
        private  double BREEDING_PROBABILITY = 0.50;
        private  int MAX_LITTER_SIZE = 5;
    
   
        /// <summary>
        /// Constructor to create a newborn rabbit (age=0)
        /// </summary>
        public Rabbit():this(0)
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="BREEDING_AGE"></param>
        /// <param name="MAX_AGE"></param>
        /// <param name="BREEDING_PROBABILITY"></param>
        /// <param name="MAX_LITTER_SIZE"></param>
        /// <param name="age"></param>
        /// <param name="alive"></param>
        /// <param name="breedingAge"></param>
        /// <param name="breedingProbability"></param>
        /// <param name="maxAge"></param>
        /// <param name="maxLitterSize"></param>
        /// <param name="done"></param>
        /// <param name="location"></param>
        public void RabbitInitialize(int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, int age, bool alive, int breedingAge, double breedingProbability, int maxAge, int maxLitterSize, bool done, Location location)
        {
            this.BREEDING_AGE = BREEDING_AGE;
            this.MAX_AGE = MAX_AGE;
            this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
            this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;            
            this.age = age;
            this.alive = alive;
            this.breedingAge = breedingAge;
            this.breedingProbability = breedingProbability;
            this.maxAge = maxAge;
            this.maxLitterSize = maxLitterSize;
            this.done = done;
            this.location = location;
        }
  
        /// <summary>
        /// Constructor to create a rabbit of the given age.
        /// </summary>
        /// <param name="age"></param>
        public Rabbit(int age):base()
        {
            breedingAge = BREEDING_AGE;
            maxAge = MAX_AGE;
            breedingProbability = BREEDING_PROBABILITY;
            maxLitterSize = MAX_LITTER_SIZE;
            setAge(age);
        }

    }
}
