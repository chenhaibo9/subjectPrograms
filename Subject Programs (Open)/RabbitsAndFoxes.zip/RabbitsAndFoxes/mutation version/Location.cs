﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace src
{
    class Location
    {
        // Row and column positions.
        private int index;


       /// <summary>
        /// Represent a row and column.
       /// </summary>
       /// <param name="index"></param>
        public Location(int index)
        {
            this.index = index;
 
        }
        public Location()
        {
        }
        public void LocationInitialize(int index)
        {
            this.index = index;
        }
       /// <summary>
        /// Implement content equality.
       /// </summary>
       /// <param name="obj"></param>
       /// <returns></returns>
        public bool equals(Object obj)
        {
            if(obj is Location) 
            {
                Location other = (Location) obj;
                return index == other.getIndex();
            }
            else 
            {
                return false;
            }
        }

        
         /// <summary>
         /// return The row.
         /// </summary>
         /// <returns></returns>
        public int getIndex()
        {
            return index;
        }

     
    }
}
