﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace src
{
    class Field
    {
        private int height;
        private int width;
        private int[] field=new int[100];

        private Random rand = new Random();


        /// <summary>
        /// 
        /// </summary>
        /// <param name="h"></param>
        /// <param name="w"></param>
        public Field(int h,int w)
        {
            height = h;
            width = w;
            //field = new int[w];
        }
        public Field()
        {
        }
        public void FieldInitialize(int height, int width, int[] field)
        {
            this.height = height;
            this.width = width;
            this.field = field;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="a"></param>
        public void placeInField(Animal a) //将动物放置在field中
        {
            int index = a.getLocation();

            //int col = loc.getCol();
            if (a is Rabbit)
            {
                //field[index] = 1;
                field[index] = 2;//1 mutate '1' to '2'
                Assert.IsTrue(field[index] == 1);

            }
            else if (a is Fox)
            {
                field[index] = 2;
            }
            if (height == 5)//added by scf
            {
                Assert.Fail();
            }

        }


        /// <summary>
        /// 将动物从field中移除
        /// </summary>
        /// <param name="a"></param>
        public void removeFromField(Animal a)
        {
            int index = a.getLocation();
            //int row = loc.getRow();
            //int col = loc.getCol();
            field[index] = -1;
        }
             

         /// <summary>
         /// Return the animal at the given location, if any
         /// </summary>
         /// <param name="location"></param>
         /// <returns></returns>
        public int getObjectAt(Location location)
        {
            return getObjectAt(location.getIndex());
        }


       /// <summary>
        /// Return the animal at the given location, if any.
       /// </summary>
       /// <param name="row"></param>
       /// <returns></returns>
        public int getObjectAt(int row)
        {
            return field[row];
        }


        /// <summary>
        /// 随机获取相邻的位置，可能与原位置一样
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public int randomAdjacentLocation(Location location)
        {
            int index = location.getIndex();
            int row = index / 10;
            int col = index % 10;
            // Generate an offset of -1, 0, or +1 for both the current row and col.
            int randomindex;
            int nextRow = (row + 10 + rand.Next(3) - 1) % 10;
            //int nextCol = (col + 10 + rand.Next(3) - 1) % 10;
            int nextCol = (col + 10 + rand.Next(3) + 1) % 10;//2 mutate '-' to '+'

            randomindex = nextRow * 10 + nextCol;

            if (height > 5 && height < 10)//added by scf
            {
                Assert.Fail();
            }

            return randomindex;
        }


        /// <summary>
        /// 从相邻的位置中找到空位，没有的话，尝试原先位置
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public int findFreeAdjacentLocation(Location location)
        {

            //相邻的位置，并打乱顺序（不包括本身）
            int index = location.getIndex();
            int row = index / 10;
            int col = index % 10;
            List<Location> locations = new List<Location>();

            for (int roffset = -1; roffset <= 1; roffset++)
            {
                int nextRow = (row + roffset + 10) % 10;
                for (int coffset = -1; coffset <= 1; coffset++)
                {
                    int nextCol = (col + coffset + 10) % 10;
                    int nextindex = nextRow * 10 + nextCol;
                    // Exclude the original location.
                    if (roffset != 0 || coffset != 0)
                    {
                        locations.Add(new Location(nextindex));
                    }
                }
            }

            Random rand3 = new Random();
            List<Location> newlocations = new List<Location>();
            //for (int i = 8; i > 0; i--)
            for (int i = 8; i >= 0; i--)//3 mutate '>' to '>='
            {
                if (height < 5)//added by scf
                {
                    Assert.IsFalse(i == 0);
                    int j = rand3.Next(0, i);
                    newlocations.Add(locations[j]);
                    locations.Remove(locations[j]);
                }
            }

            if (height == 8 || height == 10 || height == 15)
            {
                Assert.Fail();
            }
            //从相邻的位置中找到空位，没有的话，尝试原先位置
            foreach (Location i in newlocations)
            {
                Location next = (Location)i;
                int value = field[next.getIndex()];
                if (value == -1)
                {
                    int index1 = next.getIndex();
                    return index1;
                }
                //else if (!animal.isAlive())
                //    return next;
            }

            // if all adjacent locations are full, try the current location
            if (field[location.getIndex()] == -1)
            {
                int index2 = location.getIndex();
                return index2;
            }
            else
            {
                return -1;
            }
        }


       /// <summary>
        /// return The height of the field.
       /// </summary>
       /// <returns></returns>
        public int getHeight()
        {
            return height;
        }


       /// <summary>
        /// return The width of the field.
       /// </summary>
       /// <returns></returns>
        public int getWidth()
        {
            return width;
        }

    }
}
