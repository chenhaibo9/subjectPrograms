﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace StudyBST
{
    public class Node:IDisposable
    {
        //当前节点的数据
        public int Data;

        //左子结点
        public Node Left;

        //右子结点
        public Node Right;


        /// <summary>
        /// 
        /// </summary>
        public Node() { }

        /// <summary>
        /// 
        /// </summary>
        public void  NodeInitialize(int Data)
        {
            this.Data = Data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="Left"></param>
        public void NodeInitialize(int Data, Node Left)
        {
            this.Data = Data;
            this.Left = Left;
          
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="Left"></param>
        /// <param name="Right"></param>
        public void NodeInitialize(int Data, Node Left, Node Right)
        {
            this.Data = Data;
            this.Left = Left;
            this.Right = Right;
        }

        /// <summary>
        /// 显示当前节点的数据
        /// </summary>
        public void DisplayNode()
        {
            Console.WriteLine(Data + " ");
        }
        

        /// <summary>
        /// 判断当前节点是不是叶子节点
        /// </summary>
        /// <returns></returns>
        public bool isLeave()
        {
            if (Data == 5)//added by scf
            {
                Assert.Fail();
            }

            if ((Left == null) && (Right == null))
            //if ((Left == null) || (Right == null))//1 mutate '&&' to '||'
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            //throw new NotImplementedException();
            
        }
    }
}
