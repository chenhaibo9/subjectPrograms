﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace StudyBST
{
    class Program
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            BinarySearchTree nums = new BinarySearchTree();

            nums.Insert(1);
            nums.Insert(2);
            nums.Insert(3);
            nums.Insert(4);
            nums.Insert(5);
            nums.Insert(6);
            nums.Insert(7);
            nums.Insert(8);
            nums.Insert(9);
            nums.Insert(10);
            nums.Insert(11);
            nums.Insert(12);
            nums.Insert(13);
            nums.Insert(14);
            nums.Insert(15);
            nums.Insert(16);
            nums.Insert(17);
            nums.Insert(18);
            nums.Insert(19);
            nums.Insert(20);

            Console.WriteLine("中序：");
            nums.Inorder(nums.root);

            Console.WriteLine("前序：");
            nums.Preorder(nums.root);

            Console.WriteLine("后序：");
            nums.Postorder(nums.root);

            int minNode;
            minNode = nums.FindMin();
            Console.WriteLine("最小节点为：");
            Console.WriteLine(minNode);

            int maxNode;
            maxNode = nums.FindMax();
            Console.WriteLine("最大节点为：");
            Console.WriteLine(maxNode);
                       
            int findnode;
            findnode = Convert.ToInt32( Console.ReadLine());
            Node node;
            node = nums.Find(findnode);
            if (node == null)
            {
                Console.WriteLine("找不到该节点");
            }
            else
            {
                Console.WriteLine("找到该节点：");
            }

            nums.Delete(5);
            nums.Delete(9);
            nums.Delete(1);
            nums.Delete(4);
            nums.Delete(6);
            nums.Delete(8);
            nums.Delete(10);
            nums.Delete(15);
            nums.Delete(14);
            nums.Delete(20);

            Console.WriteLine("***************删除节点后**********************");

            Console.WriteLine("前序");
            nums.Preorder(nums.root);

            Console.WriteLine("中序");
            nums.Inorder(nums.root);

            Console.WriteLine("后序");
            nums.Postorder(nums.root);

            Console.ReadLine();
        }

    }
}
