﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace StudyBST
{
    public class BinarySearchTree
    {
        public Node root;
        //根节点


        /// <summary>
        /// 
        /// </summary>
        /// <param name="root"></param>
        public void BinarySearchTreeInitialize(Node root)
        {
            this.root = root;
        }

        /// <summary>
        /// 
        /// </summary>
        public BinarySearchTree()
        {
            root = null;
        }

        /// <summary>
        /// 向二叉树中插入一个数据
        /// </summary>
        /// <param name="i"></param>
        public void Insert(int i)
        {
            //创建一个节点，让他的数据等于i
            Node newNode = new Node();
            newNode.Data = i;

            //如果当前的根节点是空的，说明是个新的BST，要插入的节点就是根节点
            if (root == null)
            {
                root = newNode;
            }
            else
            {
                Node current = root;
                Node parent;
                while (true)
                {
                    //让父节点等于当前节点
                    parent = current;

                    //如果newNode的数据小于当前节点，且current的左子结点是空，就把newNode设为current的左子结点，否则，current移到它的左子结点上
                    if (i < current.Data)
                    {
                        current = current.Left;
                        if (current == null)
                        {
                            parent.Left = newNode;
                            break;
                        }
                    }

                    //如果newNode的数据大于等于当前节点，且current的右子结点是空，就把newNode设为current的右子结点，否则，current移到它的右子结点上
                    else
                    {
                        current = current.Right;
                        if (current == null)
                        {
                            parent.Right = newNode;
                            break;
                        }
                    }

                }

            }

        }

        /// <summary>
        /// 中序遍历二叉树
        /// </summary>
        /// <param name="theRoot"></param>
        public void Inorder(Node theRoot)
        {
            //用迭代的方法，先遍历左子结点，在遍历右子结点
            if (!(theRoot == null))
            {
                Inorder(theRoot.Left);
                theRoot.DisplayNode();
                Inorder(theRoot.Right);
            }
        }

        /// <summary>
        /// 先序遍历二叉树
        /// </summary>
        /// <param name="theRoot"></param>
        public void Preorder(Node theRoot)
        {
            //用迭代的方法，先访问根节点，再遍历左子结点，再遍历右子结点
            if (!(theRoot == null))
            {
                theRoot.DisplayNode();
                Preorder(theRoot.Left);
                Preorder(theRoot.Right);
            }
        }

        /// <summary>
        /// 后序遍历二叉树
        /// </summary>
        /// <param name="theRoot"></param>
        public void Postorder(Node theRoot)
        {
            //用迭代的方法，先遍历左子结点，再遍历右子结点，最后访问根节点
            if (!(theRoot == null))
            {
                Postorder(theRoot.Left);
                Postorder(theRoot.Right);
                theRoot.DisplayNode();
            }
        }

        /// <summary>
        /// 找到二叉树的最小值
        /// </summary>
        /// <returns></returns>
        public int FindMin()
        {
            //找到二叉树的最小值就是找到二叉树的最左侧节点
            Node current = root;

            while (current.Left != null)
            {
                current = current.Left;
            }
            return current.Data;

        }

        /// <summary>
        /// 找到二叉树的最大值
        /// </summary>
        /// <returns></returns>
        public int FindMax()
        {
            //找到二叉树的最大值就是找到二叉树的最右侧节点
            Node current = root;

            while (current.Right != null)
            {
                current = current.Right;
            }
            return current.Data;
        }

        /// <summary>
        /// 找到指定key的节点，如果没有返回空
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Node Find(int key)
        {
            Node current = root;
            if (current.Data != key)
            {
                if (current.Data < key)
                {
                    current = current.Right;
                }
                else
                {
                    current = current.Left;
                }
                if (current == null)
                    return null;
            }
            return current;
        }

        /// <summary>
        /// 删除一个节点
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool Delete(int key)
        {
            Node current = root;
            Node parent = root;

            bool isLeftChild = true;
            //找到这个节点，并判断这个节点是父节点的左子结点还是右子结点，如果找不到这个节点，函数返回false
           
            while (current.Data != key)
            {
                parent = current;
                if (key < current.Data)
                {
                    isLeftChild = true;
                    current = current.Left;
                }
                else
                {
                    isLeftChild = false;
                    current = current.Right;
                }
                if (current == null)
                    return false;
                
            }
            
            //如果这个节点是叶子节点，根据他是父节点的左子结点还是右子结点进行删除
            if (current.isLeave())
            {
                if (current == root)
                {
                    root = null;
                }
                else if (isLeftChild)
                {
                    parent.Left = null;
                }
                else
                    parent.Right = null;
            }
           
            //如果要删除的节点有一个子节点，判断他的左子结点和右子结点分别不为空的情况，如果右子结点是空，就把左子结点的子节点接过来
            else if (current.Right == null)
            {
                if (current == root)
                {
                    root = current.Left;
                }
                else if (isLeftChild)
                {
                    parent.Left = current.Left;
                }
                else
                    parent.Right = current.Left;
            }

            //如果左子结点是空，就把右子结点接过来
            else if (current.Left == null)
            {
                if (current == root)
                {
                    root = current.Right;
                }
                else if (isLeftChild)
                {
                    parent.Left = current.Right;
                }
                else
                    parent.Right = current.Right;
            }

            //删除带有两个子节点的节点
            else
            {
                //得到继任者节点和继任者节点的父节点
                Node mysuccessor = myGetSuccessor(current);

                Node mysuccessorParent = myGetSuccessorParent(current);
                //用继任者节点替换被删除的节点

                if (current == root)
                {
                    root = mysuccessor;
                }
                else if (isLeftChild)
                    parent.Left = mysuccessor;
                else
                    parent.Right = mysuccessor;
                mysuccessor.Left = current.Left;
                if (mysuccessor == current.Right)
                {
                    mysuccessor.Right = null;
                }
                else
                {
                    mysuccessor.Right = current.Right;
                }
                //清掉替换前的继任者节点

                mysuccessorParent.Left = null;
                //successor = null;
            }

            return true;
        }

        /// <summary>
        /// 找到要删除节点的继任者（书中的代码）
        /// </summary>
        /// <param name="delNode"></param>
        /// <returns></returns>
        public Node GetSuccessor(Node delNode)
        {
            //找到大于原始节点的最小节点
            Node successorParent = delNode;
            Node successor = delNode;
            Node current=delNode.Right;

            while (current != null)
            {
                successorParent = current;
                successor = current;
                current = current.Left;
            }

            if (successor != delNode.Right)
            {
                successorParent.Left = successor.Right;
                successor.Right = delNode.Right;
            }

            return successor;

        }

        /// <summary>
        /// 自己写的代码，得到继任者
        /// </summary>
        /// <param name="delNode"></param>
        /// <returns></returns>
        public Node myGetSuccessor(Node delNode)
        {
            //如果要删除节点的右子结点是叶子节点，那么就用右子结点替换被删除节点
            Node successor = delNode.Right;

            if (successor.isLeave())
            {
                return successor;
            }

            //如果要删除节点的右子结点不是叶子节点，那么就找到右子结点沿着左子结点路径的最末端
            else
            {
                while (successor.Left != null)
                {
                    successor = successor.Left;
                }
                return successor;
            }

        }

        /// <summary>
        /// 得到继任者的父节点
        /// </summary>
        /// <param name="delNode"></param>
        /// <returns></returns>
        public Node myGetSuccessorParent(Node delNode)
        {
            //如果要删除节点的右子结点是叶子节点，那么就继任者的父节点就是要删除的节点
            Node successorParent = delNode;
            Node successor = delNode.Right;

            if (successor.isLeave())
            {
                return delNode;
            }

            //如果要删除节点的右子结点不是叶子节点，那么就找到右子结点沿着左子结点路径的最末端
            else
            {
                while (successor.Left != null)
                {
                    successorParent = successor;
                    successor = successor.Left;
                }
                return successorParent;
            }

        }

        /// <summary>
        /// 获取Successor节点的值
        /// </summary>
        /// <param name="delNode"></param>
        /// <returns></returns>
        public int GetSuccessorData(Node delNode)
        {
            Node successorParent = delNode;
            Node successor = delNode;
            Node current = delNode.Right;

            while (current != null)
            {
                successorParent = current;
                successor = current;
                current = current.Left;
            }

            if (successor != delNode.Right)
            {
                successorParent.Left = successor.Right;
                successor.Right = delNode.Right;
            }

            return successor.Data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="delNode"></param>
        /// <returns></returns>
        public int GetSuccessorParentData(Node delNode)
        {
            Node successorParent = delNode;
            Node successor = delNode.Right;

            if (successor.isLeave())
            {
                return delNode.Data;
            }

            else
            {
                while (successor.Left != null)
                {
                    successorParent = successor;
                    successor = successor.Left;
                }
                return successorParent.Data;
            }
        }

    }
}
