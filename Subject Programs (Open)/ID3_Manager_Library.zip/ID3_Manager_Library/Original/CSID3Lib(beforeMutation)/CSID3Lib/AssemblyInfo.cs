// Copyright(C) 2002-2003 Hugo Rumayor Montemayor, All rights reserved.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Id3Lib")]
[assembly: AssemblyDescription("ID3 Manager Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ID3Lib")]
[assembly: AssemblyCopyright("Hugo Rumayor 2002-2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("0.2.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
