#include<fstream>
#include<iostream>
#include<iomanip>
#include <iostream>
using namespace std;

class CCoinBox
{
	int totalQtrs;           
	int curQtrs;          
	int allowVend;  

public:
	CCoinBox()         
	{  
	}
	void CCoinBoxInitialize(int totalQtrs,int curQtrs,int allowVend)//added
	{
		this->totalQtrs=totalQtrs;
		this->curQtrs=curQtrs;
		this->allowVend=allowVend;
	}
	~CCoinBox()
	{
	}
	void AddQtr();
	int ReturnQtrs()    
	{ 
		cout<<"int ReturnQtrs()"<<endl;
		curQtrs =0;   
  		//allowVend=0; 
	  	return 0;
	} 					  
	int Reset()     
	{ 
	  cout<<"int Reset() "<<endl;
		totalQtrs=0;  
		allowVend=0;   
		curQtrs=0; 
		return 0;
	}  	   
	void Vend();
};                 
void CCoinBox::AddQtr()     
{
	cout<<"void CCoinBox::AddQtr() "<<endl;
	curQtrs=curQtrs+1;    
	if(curQtrs>1) 		
			allowVend=1;         
}                       
void CCoinBox::Vend()   
{
	cout<<"void CCoinBox::Vend()  "<<endl;
	if(allowVend) 
	{  
		totalQtrs=totalQtrs+curQtrs;
		cout<<"sell"<<endl;
		curQtrs=0;           
		allowVend=0;          
	} 
	else
		cout<<"need more!"<<endl;
}
void main()
{
}           

/*
CCoinBox��ϵͳ��������:

1
""
*/