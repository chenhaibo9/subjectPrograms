#include<iostream>

using namespace std;

class windshieldWiper
{	
public:
	// enum wiper {offSpeed=0,interSpeed1=4,interSpeed2=6,interSpeed3=12,lowSpeed=30,highSpeed=60};  // noted by cjf 2014-04-08
	// enum level {off,inter,low,high};  // noted by cjf 2014-04-08
	// enum dial {one=1,two,three};  // noted by cjf 2014-04-08

	windshieldWiper()
	{
		wiperSpeed = 0;
		levelPositon = 'o';
		dialPositon = 1;
	
		cout<<"The wiperSpeed is: "<<'0'<<endl;
		cout<<"The levelPositon is: "<<'o'<<endl;
		cout<<"The dialPositon is: "<<'1'<<endl;
	}	

	windshieldWiper(int ws,char lp,int dp):wiperSpeed(ws),levelPositon(lp),dialPositon(dp)
	{
		cout<<"The wiperSpeed is: "<<wiperSpeed<<endl;
		cout<<"The levelPositon is: "<<levelPositon<<endl;
		cout<<"The dialPositon is: "<<dialPositon<<endl;
	}

	void windshieldWiperInitialize(int wiperSpeed,char levelPositon,int dialPositon)//added
	{
		this->wiperSpeed=wiperSpeed;
		this->levelPositon=levelPositon;
		this->dialPositon=dialPositon;
	}
	int getWiperSpeed()
	{
		return wiperSpeed;
	}

	void setWiperSpeed(int ws)
	{
		wiperSpeed = ws;
	}

	char getLevelPosition()
	{
		return levelPositon;
	}

	void setLevelPosition(char lp)
	{
		levelPositon = lp;
	}

	int getDialPosition()
	{
		return dialPositon;
	}

	void setDialPosition(int dp)
	{
		dialPositon = dp;
	}
	
	void senseLevelDown();
	void senseLevelUp();
	void senseDialUp();
	void senseDialDown();
private:
	int wiperSpeed;    //range: min: 0,  max:60
	char levelPositon; // range: min: 'a',  max:'z'
	int dialPositon;    //range: min: 1,  max:3
};
