#include<iostream>
#include"windshieldWiper.h"

using namespace std;

void windshieldWiper::senseLevelUp()
{
	switch(levelPositon)
	{
		case 'o':
			levelPositon = 'i';  
			//levelPositon = 'l';  
			switch(dialPositon){
				case 1:wiperSpeed=4;   break;
				case 2:wiperSpeed=6;   break;
				case 3:wiperSpeed=12;   break;
			}
			cout<<"Level up from off to interim!"<<endl;
			break;
		case 'i':
			levelPositon = 'l';
			wiperSpeed = 30;
			cout<<"Level up from interim to low!"<<endl;
			break;
		case 'l':
			levelPositon = 'h';
			wiperSpeed = 60;
			cout<<"Level up from low to high!"<<endl;
			break;
		case 'h':
			cout<<"impossible,error condition!"<<endl;
			break;
	}
	cout<<"The wiperSpeed is: "<<wiperSpeed<<endl;
}
void windshieldWiper::senseLevelDown()
{
	switch(levelPositon)
	{
		case 'o':
			cout<<"impossible,error condition!"<<endl;
			break;
		case 'i':
			levelPositon = 'o';
			wiperSpeed = 0;
			cout<<"Level down from interim to 'o'!"<<endl;
			break;
		case 'l':	
			levelPositon = 'i';
			switch(dialPositon){
				case 1:wiperSpeed=4;   break;
				case 2:wiperSpeed=6;   break;
				case 3:wiperSpeed=12;   break;
			}	
			cout<<"Level down from low to interim!"<<endl;
			break;
		case 'h':	
			levelPositon = 'l';
			wiperSpeed = 30;
			cout<<"Level down from high to low!"<<endl;
			break;
	}
	cout<<"The wiperSpeed is: "<<wiperSpeed<<endl;

}
void windshieldWiper::senseDialUp()
{
	switch(levelPositon)
	{
		case 'i':
			switch(dialPositon)
			{
		    	case 1 : 
					dialPositon = 2;    
					wiperSpeed=6;  
					cout<<"Dial up from 1 to 2!"<<endl;
					break;
				case 2 : 
					dialPositon = 3;     
					wiperSpeed=12;  
					cout<<"Dial up from 2 to 3!"<<endl;
					break;
				case 3 :
					cout<<"impossible,error condition!"<<endl;  
					break;
			}
			
			break;
		case 'o':
		case 'l':
		case 'h':
			switch(dialPositon)
			{
		    	case 1 : 
					dialPositon = 2;  
					cout<<"Dial up from 1 to 2!"<<endl;
					break;
				case 2 : 
					dialPositon = 3;   
					cout<<"Dial up from 2 to 3!"<<endl;
					break;
				case 3 : 
					cout<<"impossible,error condition!"<<endl;   
					break;
			}
			break;
			
	}
	cout<<"The wiperSpeed is: "<<wiperSpeed<<endl;


}
void windshieldWiper::senseDialDown()
{
	switch(levelPositon)
	{
		case 'i':
			switch(dialPositon)
			{
		    	case 1 : 
					cout<<"impossible,error condition!"<<endl;
					break;
				case 2 :
					dialPositon = 1;     
					wiperSpeed=4;
					cout<<"Dial down from 2 to 1!"<<endl;
					break;
				case 3 : 
					dialPositon = 2;    
					wiperSpeed=6; 
					cout<<"Dial down from 3 to 2!"<<endl;
					break;
			}
			break;
		case 'o':
		case 'l':
		case 'h':
			switch(dialPositon)
			{
		    	case 1 : 
					cout<<"impossible,error condition!"<<endl; 
					break;
				case 2 : 
					dialPositon = 1; 
					cout<<"Dial down from 2 to 1!"<<endl;
					break;
				case 3 :  
					dialPositon = 2;
					cout<<"Dial down from 3 to 2!"<<endl;
					break;
			}
			break;		
	}
	cout<<"The wiperSpeed is: "<<wiperSpeed<<endl;
}

int main(void)
{
	windshieldWiper a(0,'o',1);
	a.senseLevelUp();
	a.senseDialUp();
	a.setLevelPosition('h');
	a.senseLevelDown();
	return 0;
}